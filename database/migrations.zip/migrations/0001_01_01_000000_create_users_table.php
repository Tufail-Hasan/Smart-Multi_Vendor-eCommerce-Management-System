<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {

            $table->id();

            // Basic Information
            $table->string('name');

            $table->string('email')
                ->unique();

            $table->string('phone')
                ->nullable()
                ->unique();

            $table->string('avatar')
                ->nullable();

            // Authentication
            $table->timestamp('email_verified_at')
                ->nullable();

            $table->string('password');

            // User Role
            $table->enum('role', [
                'admin',
                'vendor',
                'customer',
            ])->default('customer');

            // User Account Status
            $table->boolean('status')
                ->default(true);

            $table->rememberToken();

            $table->timestamps();
        });


        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();

            $table->string('token');

            $table->timestamp('created_at')->nullable();
        });


        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();

            $table->foreignId('user_id')
                ->nullable()
                ->index();

            $table->string('ip_address', 45)
                ->nullable();

            $table->text('user_agent')
                ->nullable();

            $table->longText('payload');

            $table->integer('last_activity')
                ->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sessions');

        Schema::dropIfExists('password_reset_tokens');

        Schema::dropIfExists('users');
    }
};
